package com.amazon.AmazonDemo.service;

import org.springframework.stereotype.Service;
 
import com.amazon.AmazonDemo.Repository.ProductRepository;
import com.amazon.AmazonDemo.model.Product;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class ProductService {
    
    @Autowired
    private ProductRepository repo;   

    public List<Product> getAllProducts() {
        return repo.findAll();
    }

    public void createProduct(Product product) {
        repo.save(product);
    }
    public String getAllProductById(int id) {
    	  Optional<Product> products = repo.findById(id);
    	  if(products.isPresent()) {
    		    Product obj = products.get();
    		    return obj.toString();
    	  }else {
    		  return "Not found";
    	  }
     }  
}
