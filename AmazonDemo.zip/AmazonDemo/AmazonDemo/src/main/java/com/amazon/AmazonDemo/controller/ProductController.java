package com.amazon.AmazonDemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.amazon.AmazonDemo.model.Product;
import com.amazon.AmazonDemo.service.ProductService;
import java.util.List;

@RestController
@RequestMapping("/products")  // ✅ This makes /products available
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    @PostMapping
    public Product createProduct(@RequestBody Product product) {
        productService.createProduct(product);
        return product;
    }
   }
